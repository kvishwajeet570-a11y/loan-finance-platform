﻿"use client";

import React, { useState } from "react";
import DsaSidebar from "@/components/dsa/DsaSidebar";

export default function DSAKYCPage() {
  const [step, setStep] = useState(1);
  const [panVerified, setPanVerified] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const steps = [
    ["01", "Personal Details", "Customer information"],
    ["02", "PAN Verification", "Verify PAN"],
    ["03", "Document Upload", "Upload documents"],
    ["04", "Review & Submit", "Final submission"],
  ];

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#f5f7fb] text-slate-900">
        <DsaSidebar />
        <main className="min-h-screen lg:ml-[210px] p-5 md:p-7">
          <div className="mx-auto flex min-h-[80vh] max-w-5xl items-center justify-center">
            <div className="w-full rounded-[28px] border border-slate-200 bg-white p-10 text-center shadow-[0_18px_50px_rgba(15,23,42,.08)]">
              <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-emerald-100 text-5xl text-emerald-600">
                ✓
              </div>
              <h1 className="mt-6 text-3xl font-black">
                KYC Submitted Successfully
              </h1>
              <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-500">
                Customer KYC details have been submitted successfully for
                verification.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setStep(1);
                  setPanVerified(false);
                }}
                className="mt-7 rounded-xl bg-[#155eef] px-7 py-3 text-sm font-bold text-white shadow-lg shadow-blue-200 hover:bg-[#084dcc]"
              >
                Start New KYC
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f7fb] text-[#172033]">
      <DsaSidebar />

      <main className="min-h-screen lg:ml-[210px]">
        <div className="mx-auto max-w-[1500px] px-4 py-5 md:px-7 md:py-6">

          {/* TOP HEADER */}
          <div className="mb-5 flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div>
              <div className="text-xs font-bold uppercase tracking-[.16em] text-[#155eef]">
                DSA FinCorp / KYC
              </div>
              <h1 className="mt-1 text-2xl font-black tracking-tight md:text-3xl">
                Customer eKYC
              </h1>
              <p className="mt-1 text-sm text-slate-500">
                Manage customer identity verification and KYC submission.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden rounded-xl border border-slate-200 bg-white px-4 py-2.5 shadow-sm md:block">
                <div className="text-[10px] font-bold uppercase text-slate-400">
                  Verification Status
                </div>
                <div className="mt-1 flex items-center gap-2 text-sm font-bold">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" />
                  System Active
                </div>
              </div>

              <button
                onClick={() => {
                  setStep(1);
                  setPanVerified(false);
                }}
                className="rounded-xl bg-[#155eef] px-5 py-3 text-sm font-bold text-white shadow-lg shadow-blue-200 hover:bg-[#084dcc]"
              >
                + New KYC
              </button>
            </div>
          </div>

          {/* HERO */}
          <section className="relative overflow-hidden rounded-[26px] bg-gradient-to-r from-[#071f5c] via-[#0b4da2] to-[#087f9c] p-6 text-white shadow-[0_18px_50px_rgba(10,55,110,.18)] md:p-8">
            <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-cyan-300/10 blur-3xl" />
            <div className="absolute -bottom-32 left-[38%] h-64 w-64 rounded-full bg-blue-400/10 blur-3xl" />

            <div className="relative grid gap-7 lg:grid-cols-[1fr_330px] lg:items-center">
              <div>
                <span className="inline-flex rounded-full border border-white/20 bg-white/10 px-4 py-2 text-[10px] font-black uppercase tracking-[.15em] text-cyan-100">
                  Secure eKYC Center
                </span>

                <h2 className="mt-4 text-3xl font-black tracking-tight md:text-4xl">
                  Verify Customers Faster.
                  <br />
                  <span className="text-cyan-200">Securely.</span>
                </h2>

                <p className="mt-3 max-w-2xl text-sm leading-6 text-blue-100">
                  Complete customer verification through a simple,
                  transparent and secure KYC workflow.
                </p>

                <div className="mt-6 flex flex-wrap gap-3">
                  <div className="rounded-xl border border-white/15 bg-white/10 px-4 py-3">
                    <div className="text-[10px] text-blue-200">CURRENT STEP</div>
                    <div className="mt-1 text-sm font-black">
                      {step} / 4
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/15 bg-white/10 px-4 py-3">
                    <div className="text-[10px] text-blue-200">SECURITY</div>
                    <div className="mt-1 flex items-center gap-2 text-sm font-black">
                      <span className="h-2 w-2 rounded-full bg-emerald-400" />
                      Protected
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-[22px] border border-white/15 bg-white/10 p-5 backdrop-blur">
                <div className="text-xs font-bold text-blue-100">
                  KYC COMPLETION
                </div>

                <div className="mt-4 flex items-end justify-between">
                  <span className="text-4xl font-black">
                    {step === 1 ? "25" : step === 2 ? "50" : step === 3 ? "75" : "100"}%
                  </span>
                  <span className="text-xs text-blue-200">Progress</span>
                </div>

                <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/15">
                  <div
                    className="h-full rounded-full bg-cyan-300 transition-all duration-500"
                    style={{
                      width: `${step === 1 ? 25 : step === 2 ? 50 : step === 3 ? 75 : 100}%`,
                    }}
                  />
                </div>

                <div className="mt-4 text-xs text-blue-100">
                  {steps[step - 1][1]}
                </div>
              </div>
            </div>
          </section>

          {/* KPI CARDS */}
          <section className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Kpi icon="◈" title="Total KYC" value="248" note="+12 this month" />
            <Kpi icon="◷" title="Pending" value="36" note="Needs verification" />
            <Kpi icon="✓" title="Approved" value="192" note="77.4% approved" />
            <Kpi icon="!" title="Rejected" value="20" note="Needs attention" />
          </section>

          {/* MAIN CONTENT */}
          <section className="mt-5 grid gap-5 xl:grid-cols-[1fr_350px]">

            {/* LEFT */}
            <div className="space-y-5">

              {/* STEP NAV */}
              <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-black">
                      KYC Verification Workflow
                    </h3>
                    <p className="mt-1 text-xs text-slate-500">
                      Complete all four steps to submit customer KYC.
                    </p>
                  </div>
                  <span className="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-600">
                    Step {step} of 4
                  </span>
                </div>

                <div className="grid gap-3 md:grid-cols-4">
                  {steps.map((item, index) => {
                    const number = index + 1;
                    const active = step === number;
                    const done = step > number;

                    return (
                      <button
                        key={item[0]}
                        type="button"
                        onClick={() => done && setStep(number)}
                        className={`rounded-2xl border p-4 text-left transition ${
                          active
                            ? "border-blue-200 bg-blue-50 shadow-sm"
                            : done
                            ? "border-emerald-200 bg-emerald-50"
                            : "border-slate-100 bg-slate-50"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`flex h-10 w-10 items-center justify-center rounded-xl text-xs font-black ${
                              done
                                ? "bg-emerald-500 text-white"
                                : active
                                ? "bg-[#155eef] text-white"
                                : "bg-white text-slate-400 shadow-sm"
                            }`}
                          >
                            {done ? "✓" : item[0]}
                          </div>
                          <div>
                            <div className="text-xs font-black">
                              {item[1]}
                            </div>
                            <div className="mt-1 text-[10px] text-slate-400">
                              {item[2]}
                            </div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* STEP 1 */}
              {step === 1 && (
                <KycCard
                  title="Personal Details"
                  subtitle="Enter customer information exactly as per official documents."
                >
                  <div className="grid gap-5 md:grid-cols-2">
                    <Field label="Full Name" placeholder="Enter customer full name" />
                    <Field label="Date of Birth" type="date" />
                    <Field label="Mobile Number" placeholder="10 digit mobile number" />
                    <Field label="Email Address" placeholder="customer@email.com" />
                    <Field label="PAN Number" placeholder="ABCDE1234F" />
                    <Field label="Pincode" placeholder="6 digit pincode" />
                  </div>

                  <div className="mt-5">
                    <Field label="Address" textarea />
                  </div>

                  <div className="mt-7 flex justify-end">
                    <NextButton onClick={() => setStep(2)} />
                  </div>
                </KycCard>
              )}

              {/* STEP 2 */}
              {step === 2 && (
                <KycCard
                  title="PAN Verification"
                  subtitle="Verify PAN information before proceeding with customer KYC."
                >
                  <div className="rounded-2xl border border-blue-100 bg-blue-50 p-5">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#155eef] text-xl text-white">
                        ✓
                      </div>
                      <div>
                        <div className="font-black text-slate-800">
                          PAN Verification
                        </div>
                        <div className="mt-1 text-xs leading-5 text-slate-500">
                          Enter the PAN details and verify customer identity.
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 grid gap-5 md:grid-cols-2">
                    <Field label="PAN Number" placeholder="ABCDE1234F" />
                    <Field label="Name as per PAN" placeholder="Name exactly as PAN" />
                  </div>

                  <div className="mt-5 flex items-center justify-between rounded-2xl border border-slate-200 p-4">
                    <div>
                      <div className="text-sm font-black">Verification Status</div>
                      <div className="mt-1 text-xs text-slate-400">
                        PAN verification is required.
                      </div>
                    </div>

                    <span
                      className={`rounded-full px-3 py-1.5 text-xs font-black ${
                        panVerified
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-amber-100 text-amber-700"
                      }`}
                    >
                      {panVerified ? "Verified" : "Pending"}
                    </span>
                  </div>

                  <div className="mt-7 flex justify-between">
                    <BackButton onClick={() => setStep(1)} />
                    <div className="flex gap-3">
                      <button
                        onClick={() => setPanVerified(true)}
                        className="rounded-xl bg-indigo-600 px-5 py-3 text-xs font-black text-white hover:bg-indigo-700"
                      >
                        Verify PAN
                      </button>
                      <NextButton
                        disabled={!panVerified}
                        onClick={() => setStep(3)}
                      />
                    </div>
                  </div>
                </KycCard>
              )}

              {/* STEP 3 */}
              {step === 3 && (
                <KycCard
                  title="Document Upload"
                  subtitle="Upload clear and readable KYC documents."
                >
                  <div className="grid gap-4 md:grid-cols-2">
                    <UploadBox title="PAN Card" required />
                    <UploadBox title="Address Proof" required />
                    <UploadBox title="Bank Statement" />
                    <UploadBox title="Customer Photograph" />
                  </div>

                  <div className="mt-5 rounded-xl bg-slate-50 p-4 text-xs leading-5 text-slate-500">
                    Accepted formats: JPG, JPEG, PNG and PDF.
                  </div>

                  <div className="mt-7 flex justify-between">
                    <BackButton onClick={() => setStep(2)} />
                    <NextButton onClick={() => setStep(4)} />
                  </div>
                </KycCard>
              )}

              {/* STEP 4 */}
              {step === 4 && (
                <KycCard
                  title="Review & Submit"
                  subtitle="Review customer information before submitting KYC."
                >
                  <div className="space-y-3">
                    <ReviewRow
                      title="Personal Details"
                      value="Customer information completed"
                    />
                    <ReviewRow
                      title="PAN Verification"
                      value={panVerified ? "PAN verified" : "Verification pending"}
                    />
                    <ReviewRow
                      title="Document Upload"
                      value="KYC documents ready"
                    />
                  </div>

                  <label className="mt-5 flex cursor-pointer gap-3 rounded-2xl border border-slate-200 p-4">
                    <input type="checkbox" className="mt-1 h-4 w-4" />
                    <span className="text-xs leading-5 text-slate-500">
                      I confirm that the information and documents provided are
                      accurate and belong to the customer.
                    </span>
                  </label>

                  <div className="mt-7 flex justify-between">
                    <BackButton onClick={() => setStep(3)} />
                    <button
                      onClick={() => setSubmitted(true)}
                      className="rounded-xl bg-emerald-600 px-7 py-3 text-xs font-black text-white shadow-lg shadow-emerald-100 hover:bg-emerald-700"
                    >
                      Submit KYC ✓
                    </button>
                  </div>
                </KycCard>
              )}
            </div>

            {/* RIGHT SIDEBAR */}
            <div className="space-y-5">

              <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-black">Verification Overview</h3>
                    <p className="mt-1 text-[11px] text-slate-400">
                      Current KYC pipeline
                    </p>
                  </div>
                  <span className="rounded-lg bg-blue-50 px-2.5 py-1.5 text-[10px] font-black text-blue-600">
                    LIVE
                  </span>
                </div>

                <div className="mt-5 space-y-4">
                  <ProgressRow label="Approved" value="192" percent="77%" />
                  <ProgressRow label="Pending" value="36" percent="15%" />
                  <ProgressRow label="Rejected" value="20" percent="8%" />
                </div>
              </div>

              <div className="rounded-[24px] bg-[#101d46] p-6 text-white shadow-xl">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-xl">
                    🔐
                  </div>
                  <div>
                    <div className="font-black">Secure KYC</div>
                    <div className="mt-1 text-[10px] text-blue-200">
                      Protected verification workflow
                    </div>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-2 gap-3">
                  <MiniStat title="SECURITY" value="100%" />
                  <MiniStat title="STEP" value={`${step}/4`} />
                </div>

                <div className="mt-5 rounded-xl border border-white/10 bg-white/5 p-3 text-[11px] leading-5 text-blue-100">
                  Customer information should match the submitted KYC
                  documents before final submission.
                </div>
              </div>

              <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
                <h3 className="font-black">Quick Actions</h3>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <QuickAction icon="＋" text="New KYC" onClick={() => setStep(1)} />
                  <QuickAction icon="✓" text="Verify PAN" onClick={() => setStep(2)} />
                  <QuickAction icon="↑" text="Documents" onClick={() => setStep(3)} />
                  <QuickAction icon="↗" text="Review" onClick={() => setStep(4)} />
                </div>
              </div>
            </div>
          </section>

          {/* BOTTOM TABLE */}
          <section className="mt-5 overflow-hidden rounded-[24px] border border-slate-200 bg-white shadow-sm">
            <div className="flex flex-col justify-between gap-3 border-b border-slate-100 p-5 md:flex-row md:items-center">
              <div>
                <h3 className="font-black">Recent KYC Activity</h3>
                <p className="mt-1 text-[11px] text-slate-400">
                  Latest customer verification records
                </p>
              </div>

              <button className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50">
                View All →
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[700px] text-left">
                <thead className="bg-slate-50 text-[10px] uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="px-5 py-4">Customer</th>
                    <th className="px-5 py-4">KYC Type</th>
                    <th className="px-5 py-4">Date</th>
                    <th className="px-5 py-4">Status</th>
                    <th className="px-5 py-4">Action</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  <TableRow name="Rahul Kumar" type="Full KYC" date="02 Oct 2026" status="Approved" />
                  <TableRow name="Amit Singh" type="PAN KYC" date="02 Oct 2026" status="Pending" />
                  <TableRow name="Priya Sharma" type="Full KYC" date="01 Oct 2026" status="Approved" />
                  <TableRow name="Vikash Kumar" type="Document KYC" date="01 Oct 2026" status="Rejected" />
                </tbody>
              </table>
            </div>
          </section>

        </div>
      </main>
    </div>
  );
}

function Kpi({
  icon,
  title,
  value,
  note,
}: {
  icon: string;
  title: string;
  value: string;
  note: string;
}) {
  return (
    <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-center justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 font-black text-blue-600">
          {icon}
        </div>
        <span className="text-[10px] font-bold text-slate-400">KYC</span>
      </div>
      <div className="mt-4 text-3xl font-black">{value}</div>
      <div className="mt-1 text-xs font-bold text-slate-600">{title}</div>
      <div className="mt-1 text-[10px] text-slate-400">{note}</div>
    </div>
  );
}

function KycCard({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm md:p-6">
      <div className="mb-6">
        <h2 className="text-xl font-black">{title}</h2>
        <p className="mt-1 text-xs text-slate-400">{subtitle}</p>
      </div>
      {children}
    </div>
  );
}

function Field({
  label,
  placeholder,
  type = "text",
  textarea = false,
}: {
  label: string;
  placeholder?: string;
  type?: string;
  textarea?: boolean;
}) {
  return (
    <div>
      <label className="mb-2 block text-xs font-black text-slate-600">
        {label}
      </label>
      {textarea ? (
        <textarea
          rows={3}
          placeholder="Enter complete address"
          className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
        />
      ) : (
        <input
          type={type}
          placeholder={placeholder}
          className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
        />
      )}
    </div>
  );
}

function NextButton({
  onClick,
  disabled = false,
}: {
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className="rounded-xl bg-[#155eef] px-6 py-3 text-xs font-black text-white shadow-lg shadow-blue-100 transition hover:bg-[#084dcc] disabled:cursor-not-allowed disabled:opacity-40"
    >
      Continue →
    </button>
  );
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-xs font-black text-slate-600 hover:bg-slate-50"
    >
      ← Back
    </button>
  );
}

function UploadBox({
  title,
  required = false,
}: {
  title: string;
  required?: boolean;
}) {
  return (
    <label className="cursor-pointer rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 p-6 text-center transition hover:border-blue-400 hover:bg-blue-50">
      <input type="file" className="hidden" />
      <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-blue-100 text-lg font-black text-blue-600">
        ↑
      </div>
      <div className="mt-3 text-xs font-black text-slate-700">
        {title} {required && <span className="text-red-500">*</span>}
      </div>
      <div className="mt-1 text-[10px] text-slate-400">
        Click to upload
      </div>
    </label>
  );
}

function ProgressRow({
  label,
  value,
  percent,
}: {
  label: string;
  value: string;
  percent: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs">
        <span className="font-bold text-slate-600">{label}</span>
        <span className="font-black text-slate-800">{value}</span>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
        <div
          className="h-full rounded-full bg-[#155eef]"
          style={{ width: percent }}
        />
      </div>
    </div>
  );
}

function MiniStat({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/5 p-3">
      <div className="text-[8px] font-bold text-blue-200">{title}</div>
      <div className="mt-1 text-sm font-black">{value}</div>
    </div>
  );
}

function QuickAction({
  icon,
  text,
  onClick,
}: {
  icon: string;
  text: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="rounded-xl border border-slate-100 bg-slate-50 p-3 text-left transition hover:border-blue-200 hover:bg-blue-50"
    >
      <div className="text-lg font-black text-blue-600">{icon}</div>
      <div className="mt-2 text-[10px] font-black text-slate-600">
        {text}
      </div>
    </button>
  );
}

function ReviewRow({
  title,
  value,
}: {
  title: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <div>
        <div className="text-xs font-black">{title}</div>
        <div className="mt-1 text-[10px] text-slate-400">{value}</div>
      </div>
      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100 text-sm font-black text-emerald-600">
        ✓
      </span>
    </div>
  );
}

function TableRow({
  name,
  type,
  date,
  status,
}: {
  name: string;
  type: string;
  date: string;
  status: string;
}) {
  const statusClass =
    status === "Approved"
      ? "bg-emerald-100 text-emerald-700"
      : status === "Pending"
      ? "bg-amber-100 text-amber-700"
      : "bg-red-100 text-red-700";

  return (
    <tr className="text-xs hover:bg-slate-50">
      <td className="px-5 py-4">
        <div className="font-black">{name}</div>
        <div className="mt-1 text-[10px] text-slate-400">
          Customer KYC
        </div>
      </td>
      <td className="px-5 py-4 text-slate-500">{type}</td>
      <td className="px-5 py-4 text-slate-500">{date}</td>
      <td className="px-5 py-4">
        <span className={`rounded-full px-3 py-1.5 text-[10px] font-black ${statusClass}`}>
          {status}
        </span>
      </td>
      <td className="px-5 py-4">
        <button className="rounded-lg border border-slate-200 px-3 py-1.5 text-[10px] font-bold text-slate-600 hover:bg-white">
          View
        </button>
      </td>
    </tr>
  );
}
